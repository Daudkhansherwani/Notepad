// vm/NotesViewModel.kt
package ca.bishops.cs330.notepad.s002353155.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ca.bishops.cs330.notepad.s002353155.data.Note
import ca.bishops.cs330.notepad.s002353155.data.NoteRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** UI State: immutable snapshot the UI observes (stateless Composables render this) */
data class NotesUiState(
    val list: List<Note> = emptyList(),           // visible notes
    val query: String = "",                       // search query (extra)
    val sortByTitle: Boolean = false,             // sort toggle (extra)
    val lastDeleted: Note? = null                 // for undo (extra)
)

/** ViewModel owns UI state and handles all intents; survives rotation */
@OptIn(FlowPreview::class)
class NotesViewModel(private val repo: NoteRepository) : ViewModel() {

    // Mutable state inside VM; UI observes as StateFlow (unidirectional data flow)
    private val query = MutableStateFlow("")
    private val sortByTitle = MutableStateFlow(false)
    private val lastDeleted = MutableStateFlow<Note?>(null)

    // The core stream from the repo reacts to query; then sort as needed
    private val notesFlow: Flow<List<Note>> = query
        .debounce(150)                                 // type-ahead search
        .flatMapLatest { q -> repo.observeQuery(q) }
        .combine(sortByTitle) { notes, sortByTitle ->
            if (sortByTitle) notes.sortedWith(compareBy<Note> { !it.pinned }.thenBy { it.title })
            else notes.sortedWith(compareBy<Note> { !it.pinned }.thenByDescending { it.updatedAt })
        }

    // Expose immutable UI state stream
    val uiState: StateFlow<NotesUiState> = combine(
        notesFlow, query, sortByTitle, lastDeleted
    ) { list, q, sort, deleted ->
        NotesUiState(list = list, query = q, sortByTitle = sort, lastDeleted = deleted)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotesUiState())

    /** Intent: user typed in search box */
    fun onQueryChange(q: String) { query.value = q }

    /** Intent: toggle sorting mode (extra) */
    fun toggleSort() { sortByTitle.value = !sortByTitle.value }

    /** Intent: pin/unpin a note (extra) */
    fun togglePin(note: Note) = viewModelScope.launch {
        repo.save(note.copy(pinned = !note.pinned))
    }

    /** Intent: create/save a note */
    fun save(title: String, content: String, id: Long? = null) = viewModelScope.launch {
        val entity = if (id == null) Note(title = title, content = content)
        else repo.get(id)?.copy(title = title, content = content) ?: return@launch
        repo.save(entity)
    }

    /** Intent: delete a note; remember for undo (extra) */
    fun delete(note: Note) = viewModelScope.launch {
        repo.delete(note)
        lastDeleted.value = note
    }

    /** Intent: undo delete (extra) */
    fun undoDelete() = viewModelScope.launch {
        lastDeleted.value?.let { repo.save(it.copy(id = 0L)) }   // reinsert as new row
        lastDeleted.value = null
    }
    /** Load a single note by id (used by the editor quick-fix) */
    suspend fun load(id: Long): Note? = repo.get(id)
}

/** Simple factory to inject the repository without a service locator (per A3 spec) */
class NotesViewModelFactory(private val repo: NoteRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        require(modelClass.isAssignableFrom(NotesViewModel::class.java))
        @Suppress("UNCHECKED_CAST") return NotesViewModel(repo) as T
    }
}

