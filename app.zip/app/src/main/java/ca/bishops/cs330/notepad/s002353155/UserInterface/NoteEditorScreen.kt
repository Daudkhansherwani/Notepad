// ui/NoteEditorScreen.kt
package ca.bishops.cs330.notepad.s002353155.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Stateless Editor — gets title/content and callbacks; no DB logic */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    title: String,
    content: String,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onSave: () -> Unit,
    onDelete: (() -> Unit)? = null,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Note") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = { TextButton(onClick = onSave) { Text("Save") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {
            OutlinedTextField(
                value = title, onValueChange = onTitleChange,
                modifier = Modifier.fillMaxWidth(), label = { Text("Title") }
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = content, onValueChange = onContentChange,
                modifier = Modifier.fillMaxWidth().height(240.dp),
                label = { Text("Content") }
            )
            if (onDelete != null) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
