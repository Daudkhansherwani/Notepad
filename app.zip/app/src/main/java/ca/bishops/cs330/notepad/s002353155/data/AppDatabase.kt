// data/AppDatabase.kt
package ca.bishops.cs330.notepad.s002353155.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/** Room database — provides DAO; simple singleton provider for app scope */
@Database(entities = [Note::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        /** Create or return the single DB instance (ok as a simple provider) */
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "notepad-db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
