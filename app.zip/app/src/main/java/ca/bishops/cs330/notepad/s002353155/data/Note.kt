// data/Note.kt
package ca.bishops.cs330.notepad.s002353155.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Entity persisted by Room — single source of truth record */
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,     // unique row id
    val title: String,                                      // note title
    val content: String,                                    // note body
    val pinned: Boolean = false,                            // extra: pin/favorite
    val updatedAt: Long = System.currentTimeMillis()        // sorting/timestamps
)
