// MainActivity.kt (navigation + wiring VM/Repo/DB; UI is stateless)
package ca.bishops.cs330.notepad.s002353155

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import ca.bishops.cs330.notepad.s002353155.data.AppDatabase
import ca.bishops.cs330.notepad.s002353155.data.Note
import ca.bishops.cs330.notepad.s002353155.data.NoteRepositoryImpl
import ca.bishops.cs330.notepad.s002353155.ui.NoteEditorScreen
import ca.bishops.cs330.notepad.s002353155.ui.NotesListScreen
import ca.bishops.cs330.notepad.s002353155.vm.NotesViewModel
import ca.bishops.cs330.notepad.s002353155.vm.NotesViewModelFactory
import ca.bishops.cs330.notepad.s002353155.ui.theme.NotepadTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect


/** Activity: hosts Compose and Navigation; contains no business logic */
class MainActivity : ComponentActivity() {

    // Provide Repository via Factory (per A3 spec; no service locator)
    private val vm: NotesViewModel by viewModels {
        val dao = AppDatabase.get(this).noteDao()
        NotesViewModelFactory(NoteRepositoryImpl(dao))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            NotepadTheme {
                val nav = rememberNavController()

                NavHost(navController = nav, startDestination = "list") {

                    // List screen route
                    composable("list") {
                        val state by vm.uiState.collectAsStateWithLifecycle()

                        NotesListScreen(
                            state = state,
                            onQueryChange = vm::onQueryChange,
                            onToggleSort = vm::toggleSort,
                            onAddNew = { nav.navigate("edit?noteId=-1") },
                            onOpen = { id -> nav.navigate("edit?noteId=$id") },
                            onTogglePin = vm::togglePin,
                            onDelete = vm::delete,
                            onUndoDelete = vm::undoDelete,
                            onShare = { note -> shareNote(note) }   // extra: share
                        )
                    }

                    // Editor route with optional noteId
                    composable(
                        route = "edit?noteId={noteId}",
                        arguments = listOf(navArgument("noteId") {
                            type = NavType.LongType; defaultValue = -1L
                        })

                    ) { backStack ->
                        val id = backStack.arguments?.getLong("noteId") ?: -1L

                        var title by rememberSaveable(id) { mutableStateOf("") }
                        var content by rememberSaveable(id) { mutableStateOf("") }


                        // Load existing note once (if editing)
                        LaunchedEffect(id) {
                            if (id != -1L) {
                                val existing = vm.load(id)   // add this function in VM (shown below)
                                if (existing != null) {
                                    title = existing.title
                                    content = existing.content
                                }
                            } else {
                                title = ""
                                content = ""
                            }
                        }


                        NoteEditorScreen(
                            title = title,
                            content = content,
                            onTitleChange = { title = it },
                            onContentChange = { content = it },
                            onSave = {
                                vm.save(title, content, id = if (id == -1L) null else id)
                                nav.popBackStack()
                            },
                            onDelete = if (id == -1L) null else {
                                {
                                    // Delete using a shadow note (we only know id/title/content after user edits)
                                    vm.delete(Note(id = id, title = title, content = content))
                                    nav.popBackStack()
                                }
                            },
                            onBack = { nav.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    /** Extra: Share a note using ACTION_SEND */
    private fun shareNote(note: Note) {
        val text = "${note.title}\n\n${note.content}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, note.title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "Share note"))
    }
}
