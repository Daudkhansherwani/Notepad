// data/NoteRepository.kt
package ca.bishops.cs330.notepad.s002353155.data

import kotlinx.coroutines.flow.Flow

/** Abstraction so ViewModel depends on a clean interface (testable) */
interface NoteRepository {
    fun observeAll(): Flow<List<Note>>                      // reactive list
    fun observeQuery(query: String): Flow<List<Note>>       // reactive search
    suspend fun save(note: Note)                            // create/update
    suspend fun delete(note: Note)                          // remove
    suspend fun get(id: Long): Note?                        // load single
}

/** Concrete Room-backed repository; no Android UI/Context fields here */
class NoteRepositoryImpl(private val dao: NoteDao) : NoteRepository {
    override fun observeAll(): Flow<List<Note>> = dao.observeAll()
    override fun observeQuery(query: String): Flow<List<Note>> =
        if (query.isBlank()) dao.observeAll() else dao.observeSearch("%$query%")
    override suspend fun save(note: Note) { dao.upsert(note.copy(updatedAt = System.currentTimeMillis())) }
    override suspend fun delete(note: Note) { dao.delete(note) }
    override suspend fun get(id: Long): Note? = dao.getById(id)
}
