// data/NoteDao.kt
package ca.bishops.cs330.notepad.s002353155.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** DAO — no UI/lifecycle references; Flow for reactive reads */
@Dao
interface NoteDao {

    @Query("SELECT * FROM notes ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<Note>>                       // reactive stream

    @Query("""
        SELECT * FROM notes 
        WHERE title LIKE :q OR content LIKE :q
        ORDER BY pinned DESC, updatedAt DESC
    """)
    fun observeSearch(q: String): Flow<List<Note>>           // search extra

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long                     // create/update

    @Delete
    suspend fun delete(note: Note)                           // delete by entity

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getById(id: Long): Note?                     // load one
}
