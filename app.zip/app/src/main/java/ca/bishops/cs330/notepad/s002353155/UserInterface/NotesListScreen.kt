// ui/NotesListScreen.kt
package ca.bishops.cs330.notepad.s002353155.ui

import android.text.format.DateUtils
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ca.bishops.cs330.notepad.s002353155.data.Note
import ca.bishops.cs330.notepad.s002353155.vm.NotesUiState

/** Stateless List screen — receives data + callbacks; no business logic here */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesListScreen(
    state: NotesUiState,
    onQueryChange: (String) -> Unit,
    onToggleSort: () -> Unit,
    onAddNew: () -> Unit,
    onOpen: (Long) -> Unit,
    onTogglePin: (Note) -> Unit,
    onDelete: (Note) -> Unit,
    onUndoDelete: () -> Unit,
    onShare: (Note) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notepad") },
                actions = {
                    // Extra: sort toggle
                    IconButton(onClick = onToggleSort) { Text(if (state.sortByTitle) "A→Z" else "Time") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddNew) { Text("+") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(12.dp)) {

            // Extra: search box (query lives in VM)
            OutlinedTextField(
                value = state.query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search…") }
            )

            Spacer(Modifier.height(8.dp))

            // Notes list — stateless render of current list
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.list, key = { it.id }) { note ->
                    NoteRow(
                        note = note,
                        onClick = { onOpen(note.id) },
                        onTogglePin = { onTogglePin(note) },
                        onDelete = { onDelete(note) },
                        onShare = { onShare(note) }
                    )
                }
            }

            // Extra: Undo snackbar hint — in a simple project we can show a text/button
            state.lastDeleted?.let {
                Spacer(Modifier.height(8.dp))
                AssistChip(onClick = onUndoDelete, label = { Text("Undo delete") })
            }
        }
    }
}

/** One row preview for a note — stateless, easy to reuse/test */
@Composable
private fun NoteRow(
    note: Note,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {

            // Pinned indicator / toggle (extra)
            AssistChip(onClick = onTogglePin, label = { Text(if (note.pinned) "Pinned" else "Pin") })

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(note.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    text = note.content.take(120),
                    style = MaterialTheme.typography.bodyMedium
                )
                // Extra: relative time (e.g., "3 min ago")
                Text(
                    text = DateUtils.getRelativeTimeSpanString(note.updatedAt).toString(),
                    style = MaterialTheme.typography.labelSmall
                )
            }

            // Overflow-ish actions (share/delete)
            TextButton(onClick = onShare) { Text("Share") }
            TextButton(onClick = onDelete) { Text("Delete") }
        }
    }
}
